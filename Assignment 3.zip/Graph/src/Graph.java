import java.util.*;

class Graph {
    private int V;
    private int[][] adj;

    Graph(int v) {
        V = v;
        adj = new int[V][V];
    }

    void addEdge(int v, int w) {
        adj[v][w] = 1;
    }

    void DFSUtil(int v, boolean visited[]) {
        visited[v] = true;
        System.out.print((v + 1) + " "); // Adjusting index to start from 1

        for (int i = 0; i < V; i++) {
            if (adj[v][i] == 1 && !visited[i]) {
                DFSUtil(i, visited);
            }
        }
    }

    void DFS(int v) {
        boolean visited[] = new boolean[V];
        DFSUtil(v, visited);
        System.out.println();
    }

    void findCycles(int v, boolean visited[], int[] cycle, int cycleIndex) {
        visited[v] = true;
        cycle[cycleIndex] = v;
        cycleIndex++;

        for (int i = 0; i < V; i++) {
            if (adj[v][i] == 1) {
                if (!visited[i]) {
                    findCycles(i, visited, cycle, cycleIndex);
                } else {
                    int startIndex = indexOf(cycle, i);
                    if (startIndex != -1) {
                        System.out.print("Cycle: ");
                        for (int j = startIndex; j < cycleIndex; j++) {
                            System.out.print((cycle[j] + 1) + " ");
                            if (j == cycleIndex - 1)
                                System.out.print(cycle[startIndex] + 1);
                        }
                        System.out.println();
                    }
                }
            }
        }
        cycleIndex--;
    }

    void printCycles(int v) {
        boolean visited[] = new boolean[V];
        int[] cycle = new int[V];
        System.out.println("Cycles (starting from vertex " + (v + 1) + "):");
        findCycles(v, visited, cycle, 0);
    }

    void BFS(int s) {
        boolean visited[] = new boolean[V];
        int[] queue = new int[V];
        int front = 0, rear = 0;
        visited[s] = true;
        queue[rear++] = s;

        while (front != rear) {
            s = queue[front++];
            System.out.print((s + 1) + " "); // Adjusting index to start from 1

            for (int i = 0; i < V; i++) {
                if (adj[s][i] == 1 && !visited[i]) {
                    visited[i] = true;
                    queue[rear++] = i;
                }
            }
        }
    }

    boolean isBipartite() {
        int[] color = new int[V];
        Arrays.fill(color, -1);

        for (int i = 0; i < V; ++i) {
            if (color[i] == -1) {
                if (!isBipartiteUtil(i, color))
                    return false;
            }
        }
        return true;
    }

    boolean isBipartiteUtil(int v, int[] color) {
        int[] queue = new int[V];
        int front = 0, rear = 0;
        color[v] = 1;
        queue[rear++] = v;

        while (front != rear) {
            int u = queue[front++];

            for (int i = 0; i < V; i++) {
                if (adj[u][i] == 1) {
                    if (color[i] == -1) {
                        color[i] = 1 - color[u];
                        queue[rear++] = i;
                    } else if (color[i] == color[u]) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    boolean contains(int[] arr, int element) {
        for (int i : arr) {
            if (i == element) {
                return true;
            }
        }
        return false;
    }

    int indexOf(int[] arr, int element) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == element) {
                return i;
            }
        }
        return -1;
    }

    void printGraph() {
        for (int i = 0; i < V; ++i) {
            System.out.print("Vertex " + (i + 1) + " -> ");
            for (int j = 0; j < V; j++) {
                if (adj[i][j] == 1) {
                    System.out.print((j + 1) + " "); // Adjusting index to start from 1
                }
            }
            System.out.println();
        }
    }

    void printTreeFromLeft(int startVertex) {
        System.out.println("Tree from Left (starting from vertex " + (startVertex + 1) + "):");
        int level = 0;
        Queue<Integer> queue = new LinkedList<>();
        boolean[] visited = new boolean[V];

        queue.add(startVertex);
        visited[startVertex] = true;

        while (!queue.isEmpty()) {
            int size = queue.size();
            System.out.print("Level " + level + ": ");

            for (int i = 0; i < size; i++) {
                int vertex = queue.poll();
                System.out.print((vertex + 1) + " ");

                for (int j = 0; j < V; j++) {
                    if (adj[vertex][j] == 1 && !visited[j]) {
                        queue.add(j);
                        visited[j] = true;
                    }
                }
            }

            System.out.println();
            level++;
        }
    }

    void printTreeFromRight(int startVertex) {
        System.out.println("Tree from Right (starting from vertex " + (startVertex + 1) + "):");
        int level = 0;
        Queue<Integer> queue = new LinkedList<>();
        boolean[] visited = new boolean[V];

        queue.add(startVertex);
        visited[startVertex] = true;

        while (!queue.isEmpty()) {
            int size = queue.size();
            System.out.print("Level " + level + ": ");

            List<Integer> levelNodes = new ArrayList<>();

            for (int i = 0; i < size; i++) {
                int vertex = queue.poll();
                levelNodes.add(vertex);

                for (int j = 0; j < V; j++) {
                    if (adj[vertex][j] == 1 && !visited[j]) {
                        queue.add(j);
                        visited[j] = true;
                    }
                }
            }

            // Print nodes in reverse order
            for (int i = levelNodes.size() - 1; i >= 0; i--) {
                System.out.print((levelNodes.get(i) + 1) + " ");
            }

            System.out.println();
            level++;
        }
    }



   public static void main(String args[]) {
	   int[] vertices = {1, 2, 3, 4};
                int[][] edges = {{1, 3}, {1, 4}, {2, 1}, {2, 3}, {3, 4}, {4, 1}, {4, 2}};

                Graph g = new Graph(vertices.length);

                for (int[] edge : edges) {
                    g.addEdge(edge[0] - 1, edge[1] - 1); // Adjusting indices to start from 0
                }

                System.out.println("Graph adjacency list representation:");
                g.printGraph();

                int startVertex = 0; // Adjust as needed
                System.out.println("\nDFS traversal (starting from vertex " + (startVertex + 1) + "):");
                g.DFS(startVertex); // Starting from vertex 1, adjusting to 0-based index

                System.out.println("\nBFS traversal (starting from vertex " + (startVertex + 1) + "):");
                g.BFS(startVertex); // Starting from vertex 1, adjusting to 0-based index

                System.out.println("\nIs the graph bipartite? " + g.isBipartite());

                g.printCycles(startVertex);

                g.printTreeFromLeft(startVertex);
                g.printTreeFromRight(startVertex);
                }
                }

